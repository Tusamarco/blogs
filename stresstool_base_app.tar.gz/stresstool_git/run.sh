java -classpath "./*:./lib/*" net.tc.stresstool.StressTool --defaults-file=$1 $2
